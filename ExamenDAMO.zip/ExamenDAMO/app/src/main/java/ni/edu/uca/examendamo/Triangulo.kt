package ni.edu.uca.examendamo

import kotlin.math.sqrt

class Triangulo(ladoA: Double, ladoB: Double, ladoC: Double)
{
    val a : Double
    val b : Double
    val c : Double
    val perimetro : Double
    val area : Double

    init{
        a = ladoA
        b = ladoB
        c = ladoC
        perimetro = a + b + c
        area = sqrt((a+b-c)*(a-b+c)*(-a+b+c)*(a+b+c))/4
    }
}