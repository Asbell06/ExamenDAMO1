package ni.edu.uca.examendamo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val equilatero=findViewById<TextView>(R.id.equilatero)
        val isóceles=findViewById<TextView>(R.id.isósceles)
        val escaleno=findViewById<TextView>(R.id.escaleno)

        val equilatero=findViewById<Button>(R.id.equilatero)
        equilatero.setOnClickListener {
            val txt1 = findViewById<EditText>(R.id.txt1)
            val nro1 = txt1.text.toString().toInt()
            val nro2 = txt2.text.toString().toInt()
            val suma = nro1 + nro2
            rslt.text = "Resultado: ${suma.toString()}"





            tipoTriangulo()
    }
    private fun tipoTriangulo (args: Array<String>){

        if (ladoA = ladoB && ladoB = ladoC) {
            println("Es equilátero")
        }else if (ladoA != ladoB && ladoB != ladoC){
            println("Es escaleno")
        }else {
            println("Es isóceles")
        }
    }
}